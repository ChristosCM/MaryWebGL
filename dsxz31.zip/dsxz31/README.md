README
#Instructions
To run the application, simply unzip the folder, navigate to scene/ and run the scene.html file. This will open the application to your default browser. It has been tested on FireFox (in Linux) so use that to open it.

#Features
I have modelled the St. Mary's College in Durham. I have also added trees that rotate (there is an optical illusion). There is a bird moving around the scene that can be stopped with SPACE. There is also a kite that can be controlled with the ARROW KEYS. The kite also has a string that approximates how a real kite string functions (moves along with kite movement). The scenery can also be moved using WASD, U,J and MOUSE. Lastly you can turn lighting off and on using L. There are also instructions on the webpage on how to use the different items.

#Photo of Mary's can be found in the folder as: marys.jpg
